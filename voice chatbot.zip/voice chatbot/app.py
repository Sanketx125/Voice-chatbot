
from flask import Flask, render_template, request, jsonify
import openai

# APL LINK: 
openai.api_key = 'PASTE YOUR APL HERE'

def get_openai_response(messages):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        max_tokens=100,
    )
    return response['choices'][0]['message']['content']

app = Flask(__name__)

@app.route("/")
def index():
    return render_template('chat.html')

@app.route("/get", methods=["GET", "POST"])
def chat():
    msg = request.form["msg"]
    input = msg
    chat_messages = [
        {'role': 'system', 'content': 'You are a super intelligent assistant'},
        {'role': 'user', 'content': input}
    ]
    return jsonify({"response": get_openai_response(chat_messages)})

if __name__ == '__main__':
    app.run(debug=True)


#----------------------------------------------------------------------------------------

